package com.example.smallfry.entity;
public class ModEntities {}