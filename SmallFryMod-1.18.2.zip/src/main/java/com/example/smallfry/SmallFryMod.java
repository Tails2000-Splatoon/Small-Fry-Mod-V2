package com.example.smallfry;
public class SmallFryMod {}